import { AppError } from "../../utils/app-error";
import { accionCorrectivaRepository } from "./accion-correctiva.repository";
import prisma from "../../config/prisma";

export const accionCorrectivaService = {
  async getAll() {
    return accionCorrectivaRepository.findAll();
  },

  async create(data: {
    id_casi_accidente: number;
    descripcion: string;
    id_usuario_responsable: number;
    prioridad: string;
    fecha_compromiso: string | Date;
  }) {
    // 1. Validar que el caso exista
    const caso = await prisma.casi_accidentes.findUnique({
      where: { id_casi_accidente: Number(data.id_casi_accidente) },
    });
    if (!caso) {
      throw new AppError("El caso de casi-accidente indicado no existe", 404);
    }

    // 2. Validar que el usuario responsable exista
    const usuario = await prisma.usuarios.findUnique({
      where: { id_usuario: Number(data.id_usuario_responsable) },
    });
    if (!usuario) {
      throw new AppError("El usuario responsable indicado no existe", 404);
    }

    // 3. Registrar la acción correctiva
    return accionCorrectivaRepository.create({
      id_casi_accidente: Number(data.id_casi_accidente),
      descripcion: data.descripcion,
      id_usuario_responsable: Number(data.id_usuario_responsable),
      prioridad: data.prioridad || "MEDIA",
      fecha_compromiso: new Date(data.fecha_compromiso),
    });
  },
};